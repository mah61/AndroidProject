package com.example.math_quiz;

import java.io.Serializable;

public class Calculation implements Serializable, Comparable {


    private String operationGenerated;
    private double userValue;
    private String validationAnswer;
    int score;

    public Calculation(String operationGenerated, double userValue, String validationAnswer, int score) {
        this.operationGenerated = operationGenerated;
        this.userValue = userValue;
        this.validationAnswer = validationAnswer;
        this.score = score;
    }

    public String getOperationGenerated() {
        return operationGenerated;
    }

    public void setOperationGenerated(String operationGenerated) {
        this.operationGenerated = operationGenerated;
    }

    public double getUserValue() {
        return userValue;
    }

    public void setUserValue(double userValue) {
        this.userValue = userValue;
    }

    public String getValidationAnswer() {
        return validationAnswer;
    }

    public void setValidationAnswer(String validationAnswer) {
        this.validationAnswer = validationAnswer;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }


    @Override
    public String toString() {

        return  "Operation:  " + operationGenerated + " = " + userValue + "   " + "  Rasult: " + validationAnswer + "\n";
    }


    @Override
    public int compareTo(Object o) {

         Calculation otherObj = (Calculation)o;
        return validationAnswer.compareTo(otherObj.getValidationAnswer());
    }
}

