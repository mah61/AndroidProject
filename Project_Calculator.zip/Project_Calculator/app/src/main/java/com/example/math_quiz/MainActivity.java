package com.example.math_quiz;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    final static int REQUEST_CODE1 = 1;
    TextView txtTitle,textShowGenerate;
    EditText editAnswerBox;
    Button btnGenerate, btnValidate, btnClear, btnScore, btnFinish;
    //Represent that the current state has error or not
    boolean stateError;
    //If is true the another dot is not allowed
    boolean lastDot;
    //Represent that the last pressed button is numeric or not
    boolean lastNumeric;
    //Represent that any number is entered
    boolean hasNumber;

    String validateAnswer;
    String operation;
    int score;

    ArrayList<Calculation> listOfOperation;

    double value;

    int [] numericButton = {R.id.btnZero,R.id.btn1,R.id.btn2,R.id.btn3,R.id.btn4,R.id.btn5,R.id.btn6,R.id.btn7,R.id.btn8,R.id.btn9};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initialize();
        manageButtonOnScreen();
    }

    private void initialize(){

        listOfOperation = new ArrayList<>();

        txtTitle = findViewById(R.id.textTitle);

        textShowGenerate = findViewById(R.id.textShowGenerate);

        editAnswerBox = findViewById(R.id.editAnswerBox);

        btnGenerate = findViewById(R.id.btnGenarate);

        btnValidate = findViewById(R.id.btnValidate);
        btnValidate.setEnabled(false);

        btnClear = findViewById(R.id.btnClear);

        btnScore = findViewById(R.id.btnScore);

        btnFinish = findViewById(R.id.btnFinish);

    }

    private void manageButtonOnScreen() {

        View.OnClickListener listener = new View.OnClickListener(){

        @Override
        public void onClick (View v){

            Button button = (Button) v;
          //definition for numeric value on the keyboard
            if (!stateError) {
                editAnswerBox.append(button.getText());
                hasNumber = true;
                btnValidate.setEnabled(true);
              }
             lastNumeric = true;

           }
        };

        for (int num: numericButton){

            findViewById(num).setOnClickListener(listener);
        }
        //definition for '.' on the keyboard
        findViewById(R.id.btnDot).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (lastNumeric && !stateError && !lastDot) {
                    editAnswerBox.append(".");
                    lastNumeric = false;
                    lastDot = true;
                }
            }
        });

       //definition for '-' on the keyboard

        findViewById(R.id.btnMines).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!hasNumber && !stateError){

                    editAnswerBox.append("-");
                    hasNumber = true;
                }
            }
        });
    }

    //A method to switch between buttons
      public void runMe(View v){

        int btn = v.getId();

        switch (btn){

            case R.id.btnGenarate:
                GenerateOperation();
                break;

            case R.id.btnValidate:
                ValidateAnswer();
                break;

            case R.id.btnClear:
                clearScreen();
                break;

            case R.id.btnScore:
                calculateScore();
                break;

            case R.id.btnFinish:
                finish();
                break;
        }
      }

      //This method generates an operation
      private void  GenerateOperation() {
          Random random = new Random();

          int operand1 = random.nextInt(10);
          int operand2 = random.nextInt(9) + 1;// this prevents to divided by zero like 2/0


          String operator= "!";

          int operatorSwitch = random.nextInt(4);

          switch (operatorSwitch) {

              case 0:
                  operator = "+";
                  value = operand1 + operand2;
                  break;

              case 1:
                  operator = "-";
                  value = operand1 - operand2;
                  break;

              case 2:
                  operator = "*";
                  value = operand1 * operand2;
                  break;

                  case 3:
                   operator = "/";
                   value = Math.round(((double)operand1 / operand2)*100)/100.0 ; // this is defined to round the double result

                  break;

              default:
                  operator = "!";
          }

          operation = String.valueOf(operand1)+ " " + operator + " " + String.valueOf(operand2);

          textShowGenerate.setText(operation);
      }

 //This method checks the validation of user's answer
      private void ValidateAnswer() {

          try {

              String operation = textShowGenerate.getText().toString();
              double userAnswer = Double.valueOf(editAnswerBox.getText().toString());

                  String message;

                  if (userAnswer == value) {

                      message = " Bravo!!!";
                      validateAnswer = "right";
                      score = 1;

                  } else {

                      message = " Incorrect!!!";
                      validateAnswer = "wrong";
                      score = 0;

                  }

                  textShowGenerate.setText(message);

                  Calculation calcul = new Calculation(operation, userAnswer, validateAnswer, score);
                  listOfOperation.add(calcul);

          }catch (Exception e){
              //if there is no input in the screen this message appears
              Toast.makeText(this,"Please enter a number by using this keyboard",Toast.LENGTH_LONG).show();
          }
      }

    //This method clears the screen
      private void clearScreen(){

        editAnswerBox.setText("");


        stateError = false;
        lastNumeric = false;
        lastDot = false;
        hasNumber = false;

      }

      //this method calculates the user's score and send information to the second page
      private void calculateScore(){
          int totalScore = 0;
          int count = 0;
          int percentage;

          Iterator<Calculation> iterator = listOfOperation.iterator();

          while(iterator.hasNext()){

              Calculation calcul = iterator.next();
              totalScore += calcul.getScore();
              count++;
           }

          percentage = (totalScore*100)/count;

// create a bundle to send the information to the next page
          Bundle bundle = new Bundle();
          bundle.putSerializable("bundlePack",listOfOperation);

          Intent intent = new Intent(this, Result_Page.class);
          intent.putExtra("intentPackage", bundle);
          intent.putExtra("percentage",percentage);

          startActivityForResult(intent,REQUEST_CODE1);
      }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == REQUEST_CODE1){

            String receiveData =(String) data.getStringExtra("message");

            if(resultCode == RESULT_OK)

             txtTitle.setText(receiveData);

        }
    }

}

