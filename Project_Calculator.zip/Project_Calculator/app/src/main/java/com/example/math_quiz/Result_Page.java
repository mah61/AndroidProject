package com.example.math_quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class Result_Page extends AppCompatActivity  {

    TextView txtScore;
    ListView listResult;
    EditText editTRegister;

    RadioGroup rgFilter;
    RadioButton rbAll, rbRight, rbWrong;

    Button btnShow, btnBeck;

    ArrayList<Calculation> listOfOperation;
    ArrayList<Calculation>listOfRightAnswer;
    ArrayList<Calculation>listOfWrongAnswer;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result__page);
        initilize();
    }

    private void initilize() {

        listOfRightAnswer = new ArrayList<>();
        listOfWrongAnswer = new ArrayList<>();



        txtScore = findViewById(R.id.textVScore);

        editTRegister = findViewById(R.id.editTRegister);

        rgFilter = findViewById(R.id.radioGrFilter);

        rgFilter = findViewById(R.id.radioGrFilter);

        rbAll = findViewById(R.id.rbtnAll);

        rbRight = findViewById(R.id.rbtnRight);

        rbWrong = findViewById(R.id.rbtnWrong);

        btnShow = findViewById(R.id.btnShow);

        btnBeck = findViewById(R.id.btnBack);

        //--------------------receiving the information from the first page
        Bundle bundle = getIntent().getBundleExtra("intentPackage");
        Serializable serialList = bundle.getSerializable("bundlePack");

        listOfOperation = (ArrayList<Calculation>) serialList;


        //------------------receiving the percentage
        Intent intent = getIntent();
        int percentage = intent.getIntExtra("percentage", 0);

        txtScore.setText(percentage + " %");

    }


    //Create a method to show all answers when all is checked
   private void showListOfOperations(ArrayList<Calculation> listOfOperation) {

       //------------- initialize listView

       ListView listResult = findViewById(R.id.listVResult);

       //create an adaptor for listView
       ArrayAdapter<Calculation> listAdapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1, listOfOperation);

       //assign the adapter to the listView
       listResult.setAdapter(listAdapter);

   }

   //Create a method to show right answers when right is checked
   private void showListOfRightAnswers(ArrayList<Calculation>listOfOperation){


       Iterator<Calculation> iterator = listOfOperation.iterator();

       listOfRightAnswer.clear();

       while(iterator.hasNext()){

           Calculation operation = iterator.next();

           if(operation.getValidationAnswer().equals("right")){

               listOfRightAnswer.add(operation);
           }

           //show in the listView
           ListView listResult = findViewById(R.id.listVResult);

           ArrayAdapter<Calculation> listAdapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1, listOfRightAnswer);

           listResult.setAdapter(listAdapter);


       }
    }

    //create a method to show wrong answers when wrong is checked
    private void showListOfWrongAnswers(ArrayList<Calculation>listOfOperation){

        Iterator<Calculation> iterator = listOfOperation.iterator();

        listOfWrongAnswer.clear();

        while(iterator.hasNext()){

            Calculation operation = iterator.next();

            if(operation.getValidationAnswer().equals("wrong")){

                listOfWrongAnswer.add(operation);

            }

           //show in the listView
            ListView listResult = findViewById(R.id.listVResult);

            ArrayAdapter<Calculation> listAdapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1, listOfWrongAnswer);

            listResult.setAdapter(listAdapter);
        }

    }

    //Create a method to sort list ascending when SortA is checked
    public void ascendingSort() {

        Collections.sort(listOfOperation);

        ListView listResult = findViewById(R.id.listVResult);

        ArrayAdapter<Calculation> listAdapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1, listOfOperation);

        listResult.setAdapter(listAdapter);

    }

    //Create a method to sort list ascending when SortD is checked
    public void descendingSort(){

        Collections.sort(listOfOperation,Collections.<Calculation>reverseOrder());

        ListView listResult = findViewById(R.id.listVResult);

        ArrayAdapter<Calculation> listAdapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1, listOfOperation);

        listResult.setAdapter(listAdapter);

    }

 //method Onclick for switch between two buttons
    public void clickMe(View v) {

        int btn = v.getId();

        switch (btn)
        {
            case R.id.btnShow:
                goToShow();
                break;
            case R.id.btnBack:
                goToFirstPage();
                break;
        }
    }

//Show button
    private void goToShow(){

        int radioFilter = rgFilter.getCheckedRadioButtonId();

                if( radioFilter == R.id.rbtnAll) {

                    showListOfOperations(listOfOperation);

                }else if(radioFilter == R.id.rbtnRight) {

                    showListOfRightAnswers(listOfOperation);

                }else if(radioFilter == R.id.rbtnWrong){

                    showListOfWrongAnswers(listOfOperation);

                }else if(radioFilter ==R.id.rbtnAsc){

                    ascendingSort();

               }else if(radioFilter ==R.id.rbtnDesc){

                    descendingSort();

                }
          }

//back button
    private void goToFirstPage(){

        String userName = editTRegister.getText().toString();
        String userScore = txtScore.getText().toString();

        String message = userName + ", your score is: " + userScore;


        Intent intent = new Intent();
        intent.putExtra("message",message);

        setResult(RESULT_OK,intent);
        finish();

    }

}

